create procedure getSalLevel(eno in out number,sal in out number,salLevel in out number) is
begin
  select sal into sal from employee where empno=eno;
  if(sal>=700 and sal<=3200)then
   salLevel:=1;
  elsif(sal>3200 and sal<=4400)then
   salLevel:=2;
   elsif(sal>4400 and sal<=5000)then
   salLevel:=3;
   elsif(sal>5000 and sal<=7000)then
   salLevel:=4;
   elsif(sal>7000 and sal<=9999)then
   salLevel:=5;
  end if;

end;
/

