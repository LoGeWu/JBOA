create procedure getTaxation(eno in out number) is
begin
  select sal into eno from employee where empno=eno;
  eno:=eno-3500;
   dbms_output.put_line(eno);
  if(eno<=1500) then
   eno:=eno*(3/100)-0;
   elsif(eno<=4500) then
   eno:=eno*(10/100)-105;
    elsif(eno<=9000) then
   eno:=eno*(20/100)-555;
    elsif(eno<=35000) then
   eno:=eno*(25/100)-1005;
    elsif(eno<=55000) then
   eno:=eno*(30/100)-2755;
    elsif(eno<=80000) then
   eno:=eno*(35/100)-5505;
    else
   eno:=eno*(45/100)-13505;
   end if;
   dbms_output.put_line(eno);
end;
/

