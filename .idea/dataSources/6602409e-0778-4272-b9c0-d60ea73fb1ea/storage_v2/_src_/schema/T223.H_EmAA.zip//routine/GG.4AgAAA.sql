create procedure gg(str1 in  varchar2) is
begin
  dbms_output.put_line(str1);
end;
/

