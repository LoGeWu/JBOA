create trigger TG_TEST
  before insert
  on USERS
  for each row
  when (new.id is null)
  begin
select SEQ_Userinf.nextval into:new.id from dual;
end;
/

