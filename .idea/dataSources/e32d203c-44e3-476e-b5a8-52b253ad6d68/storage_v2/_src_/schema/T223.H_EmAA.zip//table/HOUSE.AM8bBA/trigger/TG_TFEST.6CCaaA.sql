create trigger TG_TFEST
  before insert
  on HOUSE
  for each row
  when (new.id is null)
  begin
select SEQ_House.nextval into:new.id from dual;
end;
/

