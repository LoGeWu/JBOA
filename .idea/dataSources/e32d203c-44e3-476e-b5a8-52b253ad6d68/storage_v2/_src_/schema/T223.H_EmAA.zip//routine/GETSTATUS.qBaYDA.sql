create procedure getStatus(eno in out number,money in out number,dateoff in out number) is
begin
  select (sysdate-dateOff)/365 into dateoff from employee where empno=eno;
  if(dateoff>=6)then
  money:=2000;
  dbms_output.put_line(money);
  else
   dbms_output.put_line(money);
   money:=1500;
  end if;
  update employee set comm=money where empno=eno;
end;
/

