create trigger TH_TEST
  before insert
  on HOUSE
  for each row
  when (new.id is null)
  begin
select SEQ_houseInof.nextval into:new.id from dual;
end;
/

